/**
 * app.js
 * Express application — middleware stack + route mounting.
 */

require("dotenv").config();

const express = require("express");
const cors    = require("cors");
const helmet  = require("helmet");

const requestLogger = require("./middleware/requestLogger");
const { errorHandler } = require("./middleware/errorHandler");
const rateLimiter   = require("./middleware/rateLimiter");

const healthRoutes   = require("./routes/healthRoutes");
const searchRoutes   = require("./routes/searchRoutes");
const categoryRoutes = require("./routes/categoryRoutes");
const productRoutes  = require("./routes/productRoutes");

const app = express();

// ─── Security & parsing ───────────────────────────────────────────────────────
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(requestLogger);
app.use(rateLimiter);

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use("/health",       healthRoutes);
app.use("/api/search",   searchRoutes);
app.use("/api/category", categoryRoutes);
app.use("/api/product",  productRoutes);

// ─── 404 ──────────────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({
    status:  "error",
    message: `Route ${req.method} ${req.originalUrl} not found`,
    routes: [
      "GET  /health",
      "GET  /api/search?q=<keyword>&pages=<n>",
      "GET  /api/category?url=<daraz-category-url>&pages=<n>",
      "GET  /api/product?url=<daraz-product-url>",
      "POST /api/product/bulk  body: { urls: string[] }",
    ],
  });
});

// ─── Central error handler ────────────────────────────────────────────────────
app.use(errorHandler);

module.exports = app;
