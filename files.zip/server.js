/**
 * server.js
 * Entry point — starts the HTTP server and warms up the browser.
 */

const app = require("./src/app");
const { getBrowser, closeBrowser } = require("./src/browser/browserManager");

const PORT = parseInt(process.env.PORT) || 3000;

async function start() {
  // Warm up the browser so the first request isn't slow
  console.log("[Server] Warming up browser...");
  await getBrowser();

  const server = app.listen(PORT, () => {
    console.log(`\n╔════════════════════════════════════════════╗`);
    console.log(`║   Daraz Scraper API  —  running on :${PORT}   ║`);
    console.log(`╚════════════════════════════════════════════╝`);
    console.log(`\n  GET  http://localhost:${PORT}/health`);
    console.log(`  GET  http://localhost:${PORT}/api/search?q=smartphone&pages=1`);
    console.log(`  GET  http://localhost:${PORT}/api/category?url=<url>&pages=1`);
    console.log(`  GET  http://localhost:${PORT}/api/product?url=<url>`);
    console.log(`  POST http://localhost:${PORT}/api/product/bulk\n`);
  });

  // ─── Graceful shutdown ───────────────────────────────────────────────────
  async function shutdown(signal) {
    console.log(`\n[Server] ${signal} received — shutting down...`);
    server.close(async () => {
      await closeBrowser();
      console.log("[Server] Goodbye.");
      process.exit(0);
    });
  }

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT",  () => shutdown("SIGINT"));
}

start().catch((err) => {
  console.error("[Server] Failed to start:", err.message);
  process.exit(1);
});
