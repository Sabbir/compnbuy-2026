/**
 * validators.js
 * Input validation helpers for route handlers.
 */

function isValidDarazUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.hostname.endsWith("daraz.com.bd");
  } catch {
    return false;
  }
}

function parsePages(raw, max = 10) {
  const n = parseInt(raw);
  if (isNaN(n) || n < 1) return 1;
  return Math.min(n, max);
}

module.exports = { isValidDarazUrl, parsePages };
